package com.marko.memberapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;


public class RegisterScreen extends Activity {
    EditText EtUsername, EtPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.register_screen);
        EtUsername = (EditText)findViewById(R.id.etRegUser);
        EtPassword = (EditText)findViewById(R.id.etUserPass);
    }


    public void onRegister(View view) {
        String username = EtUsername.getText().toString();
        String password = EtPassword.getText().toString();
        String type = "register";
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type, username, password);

    }
    @Override
    protected void onPause(){
        super.onPause();

        EtUsername.setText("");
        EtPassword.setText("");
    }
}
