package com.marko.memberapp;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;


public class MenuScreen extends AppCompatActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.menu_screen);

        openNewMember();
        openNewPayment();
        openListMembers();
        openListPayments();
        openOnlineShop();
    }

    public void openNewMember(){
        Button buttonNewMember = (Button)findViewById(R.id.ButtonNewMember);
        buttonNewMember.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuScreen.this, AddNewMember.class));
            }

        });
    }
    public void openNewPayment(){
        Button buttonNewPayment = (Button)findViewById(R.id.ButtonNewPayment);
        buttonNewPayment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuScreen.this, AddNewPayment.class));
            }

        });
    }
    public void openListMembers(){
        Button buttonMemberList = (Button)findViewById(R.id.ButtonMemberList);
        buttonMemberList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuScreen.this, MemberListScreen.class));
            }

        });
    }
    public void openListPayments(){
        Button buttonMemberList = (Button)findViewById(R.id.ButtonPaymentList);
        buttonMemberList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuScreen.this, PaymentListScreen.class));
            }

        });
    }
    public void openOnlineShop(){
        Button buttonOnlineShop = (Button)findViewById(R.id.ButtonOnlineShop);
        buttonOnlineShop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Uri uri = Uri.parse("https://memberapp.000webhostapp.com/");
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            }


        });

    };





}



