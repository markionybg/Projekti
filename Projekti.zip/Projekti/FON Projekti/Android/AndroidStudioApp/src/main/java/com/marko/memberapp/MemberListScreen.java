package com.marko.memberapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import com.marko.memberapp.MySqlGetData.Downloader;

public class MemberListScreen extends AppCompatActivity {

    final static String urlAddress="http://192.168.1.104/jsonGetData.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.memberlist_screen);
        final ListView lv= (ListView) findViewById(R.id.lv);
        Button buttonListMembers = (Button) findViewById(R.id.btnListMembers);
        buttonListMembers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Downloader(MemberListScreen.this,urlAddress,lv).execute();
            }
        });
    }
}
