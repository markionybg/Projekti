package com.marko.memberapp;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import com.marko.memberapp.MySqlGetData1.Downloader;

public class PaymentListScreen extends AppCompatActivity {

    final static String urlAddress1="http://192.168.1.104/jsonGetData1.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.paymentlist_screen);
        final ListView lv1= (ListView) findViewById(R.id.lv1);
        Button buttonListMembers = (Button) findViewById(R.id.btnListPayments);
        buttonListMembers.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Downloader(PaymentListScreen.this,urlAddress1,lv1).execute();
            }
        });
    }
}
