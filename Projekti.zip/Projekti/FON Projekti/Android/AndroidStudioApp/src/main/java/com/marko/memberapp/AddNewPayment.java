package com.marko.memberapp;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class AddNewPayment extends AppCompatActivity {

    EditText EtMember, EtDate, EtAmount;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_payment_screen);

        EtMember = (EditText)findViewById(R.id.EtMember);
        EtDate = (EditText)findViewById(R.id.EtDate);
        EtAmount = (EditText)findViewById(R.id.EtAmount);
    }

    public void onNewPayment(View view) {
        String member = EtMember.getText().toString();
        String date = EtDate.getText().toString();
        String amount = EtAmount.getText().toString();
        String type = "addPayment";
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type, member, date, amount);

    }
    @Override
    protected void onPause(){
        super.onPause();

        EtMember.setText("");
        EtDate.setText("");
        EtAmount.setText("");
    }

}
