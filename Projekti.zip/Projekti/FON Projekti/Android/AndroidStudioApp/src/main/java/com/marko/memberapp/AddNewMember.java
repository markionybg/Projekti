package com.marko.memberapp;


import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.EditText;

public class AddNewMember extends AppCompatActivity {

    EditText EtName, EtSurname, EtAge;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.new_member_screen);

        EtName = (EditText)findViewById(R.id.EtName);
        EtSurname = (EditText)findViewById(R.id.EtSurname);
        EtAge = (EditText)findViewById(R.id.EtAge);
    }

    public void onNewMember(View view) {
        String name = EtName.getText().toString();
        String username = EtSurname.getText().toString();
        String age = EtAge.getText().toString();
        String type = "addMember";
        BackgroundWorker backgroundWorker = new BackgroundWorker(this);
        backgroundWorker.execute(type, name, username, age);

    }
    @Override
    protected void onPause(){
        super.onPause();

        EtName.setText("");
        EtSurname.setText("");
        EtAge.setText("");
    }

}
