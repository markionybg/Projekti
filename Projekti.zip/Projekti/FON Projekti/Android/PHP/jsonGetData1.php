<?php 
require "conn.php";
$sql_query = "select * from payment_list";
$result = mysqli_query($conn, $sql_query);
if($result){
	while($row = mysqli_fetch_array($result)){
		$data[]=$row;
	}
	print(json_encode($data));
}
$conn->close();
?>