<?php 
require "conn.php";
$username = $_POST["username"];
$userpass = $_POST["password"];
$result = mysqli_query($conn ,"select * from admin_data where username like '$username' and password like '$userpass';");
if(mysqli_num_rows($result) > 0) {
	$row = mysqli_fetch_assoc($result);
	$username = $row["username"];
echo "Welcome " .$username;
}
else {
echo "Error";
}

?>