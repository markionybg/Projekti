<?php 
require "conn.php";
$member = $_POST["member"];
$date = $_POST["date"];
$amount = $_POST["amount"];
$result = mysqli_query($conn ,"insert into payment_list (member, date, amount) values ('$member', '$date', '$amount');");
if($conn->query($result) === TRUE) {
echo "Payment added";
}
else {
echo "Error";
}
$conn->close();
?>