<?php 
require "conn.php";
$username = $_POST["username"];
$userpass = $_POST["password"];
$result = mysqli_query($conn ,"insert into admin_data (username, password) values ('$username', '$userpass');");
if($conn->query($result) === TRUE) {
echo "Registration successful";
}
else {
echo "Error";
}
$conn->close();
?>