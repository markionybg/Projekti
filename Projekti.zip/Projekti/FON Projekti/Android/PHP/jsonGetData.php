<?php 
require "conn.php";
$sql_query = "select * from member_list";
$result = mysqli_query($conn, $sql_query);
if($result){
	while($row = mysqli_fetch_array($result)){
		$data[]=$row;
	}
	print(json_encode($data));
}
$conn->close();
?>