<?php 
require "conn.php";
$name = $_POST["name"];
$surname = $_POST["surname"];
$age = $_POST["age"];
$result = mysqli_query($conn ,"insert into member_list (name, surname, age) values ('$name', '$surname', '$age');");
if($conn->query($result) === TRUE) {
echo "Member added";
}
else {
echo "Error";
}
$conn->close();
?>