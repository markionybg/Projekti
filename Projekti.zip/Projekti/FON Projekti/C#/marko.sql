GO
CREATE TYPE tekst FROM VARCHAR(100) NOT NULL
GO
CREATE TYPE datum FROM DATETIME NOT NULL
GO
CREATE TYPE iznos FROM REAL



create table tipproizvoda(
idtipproizvoda integer,
naziv varchar(100),
pdv real,
primary key (idtipproizvoda)
)

create table proizvod(
idproizvod integer,
naziv varchar(100),
idtipproizvoda integer,
primary key (idproizvod),
foreign key (idtipproizvoda) references tipproizvoda(idtipproizvoda)
)

create table proizvoddetalji(
idproizvod integer,
jedinicamere varchar(3) CHECK (jedinicaMere IN ('g','kg','kom')),
primary key (idproizvod),
foreign key (idproizvod) references proizvod (idproizvod)
)

create table mesto(
idmesto integer,
naziv varchar(100),
primary key (idmesto)
)

create table otpremnica (
idotpremnica integer,
datum datetime default getdate(),
datumprometa datetime,
datumvalute datetime,
idmesto integer,
nazivmesto varchar(100),
ukupaniznos real,
ukupanpdv real,
ukupaniznossapdv real,
tekuciracun varchar(100),
primary key (idotpremnica),
foreign key (idmesto) references mesto(idmesto)
)

create table stavkaotpremnica(
idotpremnica integer,
idstavkaotpremnica integer,
cena real,
kolicina integer,
idproizvod integer,
idtipproizvoda integer,
datumvaluteotpremnica datetime,
primary key (idotpremnica, idstavkaotpremnica),
foreign key (idotpremnica) references otpremnica (idotpremnica),
foreign key (idproizvod) references proizvod (idproizvod),
foreign key (idtipproizvoda) references tipproizvoda (idtipproizvoda)
)

GO
CREATE INDEX IndexTipProizvoda ON Proizvod (idTipProizvoda)

GO
CREATE INDEX IndexDatumValute ON Otpremnica (datumValute)
 
 GO
 CREATE VIEW ProizvodPogled
AS
SELECT a.idProizvod, a.naziv, a.idTipProizvoda, d.jedinicaMere
FROM Proizvod a LEFT JOIN ProizvodDetalji d ON (a.idProizvod = d.idProizvod)

GO
CREATE TRIGGER ProizvodPogled_Insert
ON ProizvodPogled
INSTEAD OF INSERT
AS
DECLARE @idProizvod INTEGER = (SELECT idProizvod FROM inserted)
DECLARE @naziv VARCHAR(100) = (SELECT naziv FROM inserted)
DECLARE @idTipProizvoda INTEGER = (SELECT idTipProizvoda FROM inserted)
DECLARE @jedinicaMere CHAR(3) = (SELECT jedinicaMere FROM inserted)
BEGIN 
	INSERT INTO Proizvod (idProizvod, naziv, idTipProizvoda) VALUES (@idProizvod, @naziv, @idTipProizvoda)
	INSERT INTO ProizvodDetalji (idProizvod, jedinicaMere) VALUES (@idProizvod, @jedinicaMere)
END

GO
CREATE TRIGGER ProizvodPogled_Update
ON ProizvodPogled
INSTEAD OF UPDATE
AS
DECLARE @idProizvod INTEGER = (SELECT idProizvod FROM inserted)
DECLARE @naziv VARCHAR(100) = (SELECT naziv FROM inserted)
DECLARE @idTipProizvoda INTEGER = (SELECT idTipProizvoda FROM inserted)
DECLARE @jedinicaMere CHAR(3) = (SELECT jedinicaMere FROM inserted)
BEGIN 
	UPDATE Proizvod SET naziv = @naziv, idTipProizvoda = @idTipProizvoda WHERE idProizvod = @idProizvod
	UPDATE ProizvodDetalji SET jedinicaMere = @jedinicaMere WHERE idProizvod = @idProizvod
END

GO
CREATE TRIGGER ProizvodPogled_Delete
ON ProizvodPogled
INSTEAD OF DELETE
AS
DECLARE @idProizvod INTEGER = (SELECT idProizvod FROM inserted)
BEGIN 
	DELETE FROM ProizvodDetalji WHERE idProizvod = @idProizvod
	DELETE FROM Proizvod WHERE idProizvod = @idProizvod
END

GO
CREATE TRIGGER Otpremnica_2NF_Trigger
ON Otpremnica
AFTER UPDATE
AS
DECLARE @idOtpremnica INTEGER
DECLARE @datumValute DATETIME
DECLARE Otpremnica_2NF_Cursor CURSOR LOCAL FOR SELECT idOtpremnica, datumValute FROM inserted
BEGIN
OPEN Otpremnica_2NF_Cursor
FETCH NEXT FROM Otpremnica_2NF_Cursor INTO @idOtpremnica, @datumValute
WHILE @@FETCH_STATUS = 0
BEGIN
ALTER TABLE StavkaOtpremnica DISABLE TRIGGER ALL
UPDATE StavkaOtpremnica
SET datumValuteOtpremnica = @datumValute
WHERE idOtpremnica = @idOtpremnica
ALTER TABLE StavkaOtpremnica ENABLE TRIGGER ALL
FETCH NEXT FROM Otpremnica_2NF_Cursor INTO @idOtpremnica, @datumValute
END	
CLOSE Otpremnica_2NF_Cursor
DEALLOCATE Otpremnica_2NF_Cursor
END

GO
CREATE TRIGGER StavkaOtpremnica_2NF_Trigger
ON StavkaOtpremnica
AFTER INSERT, UPDATE
AS
DECLARE @idOtpremnica INTEGER
DECLARE @idStavkaOtpremnica INTEGER
DECLARE StavkaOtpremnica_2NF_Cursor CURSOR LOCAL FOR SELECT idOtpremnica, idStavkaOtpremnica FROM inserted
BEGIN
OPEN StavkaOtpremnica_2NF_Cursor
FETCH NEXT FROM StavkaOtpremnica_2NF_Cursor INTO @idOtpremnica, @idStavkaOtpremnica
WHILE @@FETCH_STATUS = 0
BEGIN
alter table stavkaotpremnica disable trigger stavkaotpremnica_Opt_Trigger, StavkaOtpremnica_3NF_Trigger
UPDATE StavkaOtpremnica
SET datumValuteOtpremnica = (SELECT datumValute FROM Otpremnica WHERE idOtpremnica = @idOtpremnica)
WHERE idOtpremnica = @idOtpremnica AND idStavkaOtpremnica = @idStavkaOtpremnica
alter table stavkaotpremnica enable trigger stavkaotpremnica_Opt_Trigger, StavkaOtpremnica_3NF_Trigger
FETCH NEXT FROM StavkaOtpremnica_2NF_Cursor INTO @idOtpremnica, @idStavkaOtpremnica
END
CLOSE StavkaOtpremnica_2NF_Cursor
DEALLOCATE StavkaOtpremnica_2NF_Cursor
END

GO
CREATE TRIGGER Mesto_3NF_Trigger
ON Mesto
AFTER UPDATE
AS
DECLARE @idMesto INTEGER
DECLARE @naziv VARCHAR (100)
DECLARE Mesto_3NF_Cursor CURSOR LOCAL FOR SELECT idMesto, naziv FROM inserted
BEGIN
OPEN Mesto_3NF_Cursor
FETCH NEXT FROM Mesto_3NF_Cursor INTO @idMesto, @naziv
WHILE @@FETCH_STATUS = 0
BEGIN
ALTER TABLE Otpremnica DISABLE TRIGGER ALL
UPDATE Otpremnica
SET nazivMesto = @naziv
WHERE idMesto = @idMesto
ALTER TABLE Otpremnica ENABLE TRIGGER ALL
FETCH NEXT FROM Mesto_3NF_Cursor INTO @idMesto, @naziv
END	
CLOSE Mesto_3NF_Cursor
DEALLOCATE Mesto_3NF_Cursor
END



GO
CREATE TRIGGER Otpremnica_3NF_Trigger
ON Otpremnica
AFTER INSERT, UPDATE
AS 
DECLARE @idOtpremnica INTEGER
DECLARE @idMesto INTEGER
DECLARE Otpremnica_3NF_Cursor CURSOR LOCAL FOR SELECT idOtpremnica, idMesto FROM inserted
BEGIN
OPEN Otpremnica_3NF_Cursor
FETCH NEXT FROM Otpremnica_3NF_Cursor INTO @idOtpremnica, @idMesto
WHILE @@FETCH_STATUS = 0
BEGIN
UPDATE Otpremnica
SET nazivMesto = (SELECT naziv FROM Mesto WHERE idMesto = @idMesto)
WHERE idOtpremnica = @idOtpremnica
FETCH NEXT FROM Otpremnica_3NF_Cursor INTO @idOtpremnica, @idMesto
END
CLOSE Otpremnica_3NF_Cursor
DEALLOCATE Otpremnica_3NF_Cursor
END

GO
CREATE TRIGGER Proizvod_3NF_Trigger
ON Proizvod
AFTER UPDATE
AS
DECLARE @idProizvod INTEGER
DECLARE @idTipProizvoda INTEGER
DECLARE Proizvod_3NF_Cursor CURSOR LOCAL FOR SELECT idProizvod, idTipProizvoda FROM inserted
BEGIN
OPEN Proizvod_3NF_Cursor
FETCH NEXT FROM Proizvod_3NF_Cursor INTO @idProizvod, @idTipProizvoda
WHILE @@FETCH_STATUS = 0
BEGIN
ALTER TABLE StavkaOtpremnica DISABLE TRIGGER ALL
UPDATE StavkaOtpremnica
SET idTipProizvoda = @idTipProizvoda
WHERE idProizvod = @idProizvod
ALTER TABLE StavkaOtpremnica ENABLE TRIGGER ALL
FETCH NEXT FROM Proizvod_3NF_Cursor INTO @idProizvod, @idTipProizvoda
END	
CLOSE Proizvod_3NF_Cursor
DEALLOCATE Proizvod_3NF_Cursor
END

GO
CREATE TRIGGER StavkaOtpremnica_3NF_Trigger
ON StavkaOtpremnica
AFTER INSERT, UPDATE
AS 
DECLARE @idOtpremnica INTEGER
DECLARE @idStavkaOtpremnica INTEGER
DECLARE @idProizvod INTEGER
DECLARE StavkaOtpremnica_3NF_Cursor CURSOR LOCAL FOR SELECT idOtpremnica, idStavkaOtpremnica, idProizvod FROM inserted
BEGIN
OPEN StavkaOtpremnica_3NF_Cursor
FETCH NEXT FROM StavkaOtpremnica_3NF_Cursor INTO @idOtpremnica, @idStavkaOtpremnica, @idProizvod
WHILE @@FETCH_STATUS = 0
BEGIN
UPDATE StavkaOtpremnica
SET idTipProizvoda = (SELECT idTipProizvoda FROM Proizvod WHERE idProizvod = @idProizvod)
WHERE idOtpremnica = @idOtpremnica AND idStavkaOtpremnica = @idStavkaOtpremnica
FETCH NEXT FROM StavkaOtpremnica_3NF_Cursor INTO @idOtpremnica, @idStavkaOtpremnica, @idProizvod
END
CLOSE StavkaOtpremnica_3NF_Cursor
DEALLOCATE StavkaOtpremnica_3NF_Cursor
END


GO
CREATE PROCEDURE Otpremnica_Opt_Procedure @idOtpremnica INTEGER
AS
DECLARE @ukupanIznos REAL = (SELECT SUM (stavkaotpremnica.kolicina * stavkaotpremnica.cena) FROM stavkaotpremnica WHERE idOtpremnica = @idOtpremnica)
DECLARE @ukupanPDV REAL = (SELECT SUM (stavkaotpremnica.kolicina * stavkaotpremnica.cena * TipProizvoda.pdv) FROM stavkaotpremnica INNER JOIN TipProizvoda ON (stavkaotpremnica.idTipProizvoda = TipProizvoda.idTipProizvoda) WHERE idOtpremnica = @idOtpremnica)
DECLARE @ukupanIznosSaPDV REAL = (SELECT SUM (stavkaotpremnica.kolicina * (stavkaotpremnica.cena + (stavkaotpremnica.cena * TipProizvoda.pdv))) FROM stavkaotpremnica INNER JOIN TipProizvoda ON (stavkaotpremnica.idTipProizvoda = TipProizvoda.idTipProizvoda) WHERE idOtpremnica = @idOtpremnica)
BEGIN
	ALTER TABLE Otpremnica DISABLE TRIGGER ALL
UPDATE Otpremnica 
SET ukupanIznos = @ukupanIznos, ukupanPDV = @ukupanPDV, ukupanIznosSaPDV = @ukupanIznosSaPDV
WHERE idOtpremnica = @idOtpremnica
	ALTER TABLE Otpremnica ENABLE TRIGGER ALL
END

GO
CREATE TRIGGER Otpremnica_Opt_Trigger
ON Otpremnica
AFTER INSERT, UPDATE
AS
DECLARE @idOtpremnica INTEGER
DECLARE stavkaotpremnica_Opt_Cursor CURSOR LOCAL FOR SELECT idOtpremnica FROM inserted
BEGIN
OPEN stavkaotpremnica_Opt_Cursor
FETCH NEXT FROM stavkaotpremnica_Opt_Cursor INTO @idOtpremnica
WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC Otpremnica_Opt_Procedure @idOtpremnica
	FETCH NEXT FROM stavkaotpremnica_Opt_Cursor INTO @idOtpremnica
END
CLOSE stavkaotpremnica_Opt_Cursor
DEALLOCATE stavkaotpremnica_Opt_Cursor
END

GO
CREATE TRIGGER stavkaotpremnica_Opt_Trigger
ON stavkaotpremnica
AFTER INSERT, UPDATE
AS
DECLARE @idOtpremnica INTEGER
DECLARE stavkaotpremnica_Opt_Cursor CURSOR LOCAL FOR SELECT idOtpremnica FROM inserted
BEGIN
OPEN stavkaotpremnica_Opt_Cursor
FETCH NEXT FROM stavkaotpremnica_Opt_Cursor INTO @idOtpremnica
WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC Otpremnica_Opt_Procedure @idOtpremnica
	FETCH NEXT FROM stavkaotpremnica_Opt_Cursor INTO @idOtpremnica
END
CLOSE stavkaotpremnica_Opt_Cursor
DEALLOCATE stavkaotpremnica_Opt_Cursor
END


GO
CREATE TRIGGER stavkaotpremnica_Opt_Trigger_Del
ON stavkaotpremnica
AFTER DELETE
AS
DECLARE @idOtpremnica INTEGER
DECLARE stavkaotpremnica_Opt_Cursor CURSOR LOCAL FOR SELECT idOtpremnica FROM deleted
BEGIN
OPEN stavkaotpremnica_Opt_Cursor
FETCH NEXT FROM stavkaotpremnica_Opt_Cursor INTO @idOtpremnica
WHILE @@FETCH_STATUS = 0
BEGIN
	EXEC Otpremnica_Opt_Procedure @idOtpremnica
	FETCH NEXT FROM stavkaotpremnica_Opt_Cursor INTO @idOtpremnica
END
CLOSE stavkaotpremnica_Opt_Cursor
DEALLOCATE stavkaotpremnica_Opt_Cursor
END

